//node自带用来处理路径的
const path = require('path');
//http+url+querystring 等的合成
const express = require('express'); //重点
//设置静态文件的目录
const expressStatic = require('express-static'); //重点
//拿POST数据 --> 专门解析 类型为 application/x-www-form-urlencoded 的表单 
const bodyParser = require('body-parser');
//拿POST文件数据 --> 专门解析 类型为 multipart/form-data 的数据
const multer = require('multer');
//读取cookie --> cookie-parser
const cookieParser = require('cookie-parser');
//用于使用session的
const cookieSession = require('cookie-session');
//模拟用户数据
let users = {
  'blue': '123456',
  'kocher': '123456',
  'zhangsan': '654321',
  'lisi': '987987'
};
//实例express 
let server = express();

//1、使用cookieParser --> 解析cookie、并且告诉cookiParser 签名是啥
server.use(cookieParser('dkjlashbjfkgjkaf'));

//cookie
/*
	cookie --> 访问子目录可以向上访问 如：/aaa 可以访问aaa里面的cookie以及/根目录的cookie
	
*/
server.use('/index.html', function(request, response) {
  response.cookie('user', 'blue', {
    path: '/aaa', //设置cookie路径
    maxAge: 30 * 24 * 3600 * 1000 //过期时间
  });
  request.secret = 'dkjlashbjfkgjkaf';
  response.cookie('signedCookie', 'signed', {
    signed: true //使用签名设置cookie
  });

  console.log('签名cookie：', request.signedCookies)
  console.log('无签名cookie：', request.cookies);

  // response.clearCookie('user'); //清楚cookie
  response.send('ok');
});
//session
let arr = [];

for (let i = 0; i < 100000; i++) {
  arr.push('sig_' + Math.random());
}
//使用session 设置过期时间和密钥(keys)
server.use(cookieSession({
  name: 'sess', //session名字 --> sess.sig session 加密
  keys: arr,
  maxAge: 2 * 3600 * 1000
}));

server.use('/', function(request, response) {
  //利用session记录访问次数
  if (request.session['count'] == null) {
    request.session['count'] = 1;
  } else {
    request.session['count']++;
  }

  console.log(request.session);

  response.send('ok');
});
//监听端口、监听静态文件目录
server.use(expressStatic('./www'));
server.listen(8880);
console.log('listen call...');