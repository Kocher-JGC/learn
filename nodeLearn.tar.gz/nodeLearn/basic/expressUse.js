const express = require('express');
const expressStatic = require('express-static');

var server = express();
server.listen(8080);

//用户数据
var users = {
  'blue': '123456',
  'zhangsan': '654321',
  'lisi': '987987'
};
//get
server.get('/login', function(req, res) {
  var user = req.query['user'];
  var pass = req.query['pass'];

  if (users[user] == null) {
    res.send({
      ok: false,
      msg: '此用户不存在'
    });
  } else {
    if (users[user] != pass) {
      res.send({
        ok: false,
        msg: '密码错了'
      });
    } else {
      res.send({
        ok: true,
        msg: '成功'
      });
    }
  }
});

/*//bodyParser
const bodyParser = require('body-parser');
server.use(bodyParser.urlencoded({
  extended: false, //扩展模式
  limit: 2 * 1024 * 1024 //限制-2M
}));
server.use('/', function(req, res) {
  console.log(req.body); //POST
});*/

server.use(expressStatic('./www'));