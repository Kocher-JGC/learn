const fs = require('fs')

//readFile(文件名,回调函数)
/*fs.readFile('readFile.txt', function(err, data) {
  if (err) {
    console.log(`error --> ${err}`);
  } else {
    console.log(`data --> ${data.toString()}`);
  }
})*/

// fs.writeFile(path, data, options, callback);
fs.writeFile('writeFile.txt', 'Write some txt', function(err) {
  console.log(err);
});