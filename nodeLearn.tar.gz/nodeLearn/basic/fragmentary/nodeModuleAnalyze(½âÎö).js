//http模块 --> http协议操作
const http = require('http')
//文件操作模块
const fs = require('fs')

//创建服务                      //请求    响应(发送)
let server = http.createServer((request, response) => {
  //requert.url --> /index.html
  //要读取的路径 --> ./www/index.html
  // --> fill_name 
  let file_name = './www' + request.url;

  fs.readFile(file_name, (error, data) => {
    // console.log(data);
    if (error) {
      // console.log(error);
      response.write('404');
    } else {
      //向请求地址发送数据
      response.write(data);
    }
    response.end();
  });

});
//服务监听的端口
server.listen(8888);