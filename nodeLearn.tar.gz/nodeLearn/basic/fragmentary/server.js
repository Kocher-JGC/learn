const http = require('http')
const fs = require('fs')

let server = http.createServer((request, response) => {
  //requert.url --> /index.html
  //要读取的路径 --> ./www/index.html
  // --> fill_name 
  let file_name = './www' + request.url;

  fs.readFile(file_name, (error, data) => {
    // console.log(data);
    if (error) {
      // console.log(error);
      response.write('404');
    } else {
      response.write(data);
    }
    response.end();
  });

});

server.listen(8888);