const express = require('express');
const static = require('express-static');
const cookieParser = require('cookie-parser');
const cookieSession = require('cookie-session');
const bodyParser = require('body-parser');
const multer = require('multer');
const consolidate = require('consolidate');
const mysql = require('mysql');

let server = express();
server.listen(8888);

// 链接数据库 --> createConnection(哪台服务器, 用户名, 密码, 库)  
// var db=mysql.createConnection({host: 'localhost', user: 'root', password: '123456', database: '20161222'});

//使用链接池
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'nodebasiclearn'
});

//cookie&session
server.use(cookieParser('wssedfdcxxcv'));
/* server.use(cookieSession({
  //Array.from({length:10000}, i => 'keys_'+Math.random()) //26-37ms
  //(new Array(10000)).join('').split('').map(i => i); //20ms 去掉map() --> 2ms
  //Array.apply(null,{length:10000}).map(i=>i);  //25ms
  // for 循环生成数组2ms 加上push 6ms  为了简写就不用for了
  key: Array(1000).fill('keys_' + Math.random()), //20ms
  name: 'simple_sess_id',
  maxAge: 20 * 3600 * 1000
})); */

//post数据
server.use(bodyParser.urlencoded({
  extended: false
}));
server.use(multer({
  dest: './www/upload'
}).any());

//模板引擎配置
server.set('view engine', 'html');
server.set('views', './www/templates');
server.engine('html', consolidate.ejs);

const isError = (err, res, msg = 'database error') => err !== null ?  res.status(500).send(msg).end() : false;

//index
server.get(['/', '/index.html'], (request, response, next) => {
  db.query('SELECT * FROM banner_table', (err, data) => {
    if (isError(err,response) === false) {
      response.banners = data;
      next();
    }
  })
});
server.get(['/', '/index.html'], (request, response, next) => {
  db.query('SELECT title,summery,id FROM article_table', (err, data) => {
    if (isError(err,response) === false) {
      response.articles = data;
      next();
    }
  })
});
server.get(['/', '/index.html'], (request, response) => {
  response.render('index.ejs', {
    banners: response.banners,
    articles: response.articles
  });
});

server.get('/article', (request, response, next) => {
  if (request.query.id){
    if(request.query.act == 'like'){
      db.query(`UPDATE article_table SET n_like=n_like+1 WHERE id=${request.query.id}`,(error, data) => {
        if(isError(error, response, '点赞失败！') === false) next()
      });
    }else{
      next();
    }
  }else{
    response.status(404).send('您请求的文章找不到').end();
  }
});
server.get('/article', (request, response, next) => {
  db.query(`SELECT * FROM article_table WHERE id=${request.query.id}`, (error, data) => {
    if (isError(error, response, '文章获取失败！') === false) {
      if (data.length == 0) {
        response.status(404).send('您请求的文章找不到').end();
      } else {
        let articleData = data[0];
        //思考如何正则去重复p
        articleData.content = articleData.content.replace(/^/gm,'<p>').replace(/$/gm,'</p>');
        response.render('conText.ejs', {
          article_data: articleData
        });
      }
    }
  })
})
//4.static数据
server.use(static('./www'));