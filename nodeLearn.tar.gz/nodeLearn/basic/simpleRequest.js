//简单学习就不放入node_modules里面
//require   请求：引入模块的
//module    模块：模块定义
//exports   输出：输出
const http = require('http')
const fs = require('fs')
const urlLib = require('url')
const querystring = require('querystring')