const http = require('http')
const fs = require('fs')
const urlLib = require('url')
const querystring = require('querystring')

let server = http.createServer((request, response) => {
  console.log('server Request received..');
  // console.log('request --> ' + request.url);
  //加个true自动把（query参数）get请求格式化成json
  let urlJson = urlLib.parse(request.url, true);

  // response.write('我要显示中文', 'utf8')response.write(data, encoding)

  let pathname = urlJson.pathname;
  response.writeHead(200, {
    // 'Content-Type': 'text/plain; charset=UTF-8',
    'Content-Type': 'text/html; charset=UTF-8',
  });

  // 简单处理request请求 分文件、POST、GET处理
  switch (request.method) {
    case 'POST':
      console.log('POST');
      // console.log( request.method === 'POST'); 
      //用数组拼接buffer数据好像没问题，有问题再修改把
      let str = []; //简单嘛 --> 先只做str拼接
      request.on('data', data => {
        //new Buffer("username=admin&password=123456") //新建一个Buffer数据 --> 已被废弃
        // console.log(Buffer); //node全局变量
        //每一段给你的都是 Buffer 类型的数据
        //<Buffer 75 73 65 72 6e 61 6d 65 3d 61 64 6d 69 6e 26 70 61 73 73 77 6f 72 64 3d 31 32 33 34 35 36>
        // console.log(data);
        str.push(data);
      })
      request.on('end', function() { //无参数给你
        str = str.join('');
        const POST = querystring.parse(str);
      })
      // response.write('收到了POST数据', 'utf8');
      response.end('我要中文', 'utf8');
      break;
    case 'GET':
      console.log('GET');
      // console.log( request.method === 'GET');
      // if (pathname.endsWith('.html')) {
      // if (/\.(html|xhtml)$/.test(pathname)) {}
      response.write('收到了GET数据', 'utf8');
      const GET = urlJson.query;
      if (Object.keys(GET).length) { // 这方法太愚蠢了
        // response.end('我要中文', 'utf8');
        // break;
      }
    default:
      console.log('-->');
      let file_name = './www' + pathname;
      fs.readFile(file_name, function(error, data) {
        if (!error) {
          //为什么不需要编译 --> 机械对机械传输啊
          response.write(data);
        } else {
          response.write('404');
        }
        response.end();
      })
      break;
  }

});

server.listen(8888);

// const URL = require('url')
// const myURL = new URL('https://user:pass@sub.host.com:8080/p/a/t/h?query=string#hash');
// console.log(myURL);