/*
 1. fs.stat  检测是文件还是目录
 2. fs.mkdir  创建目录
 3. fs.writeFile  创建写入文件
 4. fs.appendFile 追加文件
 5.fs.readFile 读取文件
 6.fs.readdir读取目录
 7.fs.rename 重命名
 8. fs.rmdir  删除目录
 9. fs.unlink删除文件
*/

var fs=require('fs');
const FSC = fs.constants  // 文件操作系统常量


//1. fs.stat  检测是文件还是目录  2、同步方法 fs.statSync
// fs.stat('basic',function(err,stats){
//   if(err) return
//   console.log('文件：'+stats.isFile());
//   console.log('目录：'+stats.isDirectory());
//   console.log(JSON.stringify(stats)); // 返回的是一个fs.Stats类实例
// })
// fs.open(path, flags(文件系统)[, mode], callback)
// mode 可设置文件的模式（权限和粘滞位），但只有创建文件时才有效。 在 Windows 上，只能操作写入权限



/** 2、fs.mkdir  创建目录  接收参数： 
 * fs.mkdtemp 创建临时目录
 * fs.mkdirSync 同步  
  path           将创建的目录路径
  options {recursive,mode}      recursive 递归创建不管目录是否存在    目录权限（读写权限），默认0777
  window 下没有mode
  callback      回调，传递异常参数err 
**/
// fs.mkdir('/tmp/a/apple', { recursive: true }, (err) => {
//   if (err) return console.log(err);
//   // 创建 /tmp/a/apple 目录，不管 `/tmp` 和 /tmp/a 目录是否存在。
// });


//3. (只能覆盖文件) fs.writeFile  创建写入文件 data == (String | Buffer)
/** 参数
 *  file <string> | <Buffer> | <URL> | <integer> 文件名或文件描述符。
    data <string> | <Buffer> | <TypedArray> | <DataView>
    options        (Object)           option数组对象，包含：
    · encoding   (string)            可选值，默认 ‘utf8′，当data使buffer时，该值应该为 ignored。
    · mode         (Number)        文件读写权限，默认值 438
    · flag            (String)            默认值 ‘w'
    callback {Function}  回调，传递一个异常参数err。
 *  **/
//fs.writeFile('t.txt','我只能覆盖文件','utf8',function(err){
//  if(err) return console.log(err)
//  console.log('写入成功');
//})

/** 
fs.write() 写入数据到指定文件
fs.write(fd, buffer[, offset[, length[, position]]], callback)
// 写入 buffer 到 fd 指定的文件。
// offset 决定 buffer 中被写入的部分，length 是一个整数，指定要写入的字节数
fs.write(fd, string[, position[, encoding]], callback)
// 写入 string 到 fd 指定的文件。 如果 string 不是一个字符串，则该值将被强制转换为字符串。
// position 指向从文件开始写入数据的位置的偏移量。 如果 typeof position !== 'number'，则数据从当前位置写入。
 *  **/


//4. fs.appendFile 追加文件
// fs.appendFile(path, data[, options], callback)
/**
options <Object> | <string>
encoding <string> | <null> 默认为 'utf8'。
mode <integer> 默认为 0o666。
flag <string> 详见支持的 flag。默认为 'a'。 
**/
// fs.appendFile('t1.txt','这是写入的内容\n',function(err){
//  if(err) return console.log(err)
//  console.log('写入成功，操作的是写入文件不会覆盖，而且可以创建文件');
// })


//5.fs.readFile 读取文件
/** 
  path 如果 path 是一个文件描述符，则它不会自动关闭。
 * options <Object> | <string>
     encoding <string> | <null> 默认为 null。 
     flag <string> 详见支持的 flag。默认为 'r'。
fs.readFile() 会缓存整个文件。 为了最小化内存占用，尽可能优先使用 fs.createReadStream()。 
**/
//fs.readFile('t1.txt',function(err,data){
//  if(err) return console.log(err)
//   console.log(data.toString()); // 返回buffer 转换字符串
//})
// fs.read(fd, buffer, offset, length, position, callback) // 从 fd 指定的文件中读取数据。
/**
buffer 是数据将被写入到的 buffer。 offset 是 buffer 中开始写入的偏移量。 length 是一个整数，指定要读取的字节数。
position 指定从文件中开始读取的位置。 如果 position 为 null，则数据从当前文件读取位置开始读取，且文件读取位置会被更新。 
如果 position 为一个整数，则文件读取位置保持不变。
回调有三个参数 (err, bytesRead, buffer)。 
**/


//6.fs.readdir读取目录  把目录下面的文件和文件夹都获取到。 //readdirSync
/** 
path <string> | <Buffer> | <URL>
options <string> | <Object>
   encoding <string> 默认为 'utf8'。
   withFileTypes <boolean> 默认为 false。 
**/
// fs.readdir('html',function(err,data){
//  if(err) return console.log(err)
//  // data <string[]> | <Buffer[]> | <fs.Dirent[]>
//   console.log(data); //拿到一个文件夹下面的所有目录[是一个数组]
// })


//7.fs.rename 重命名（存在则覆盖文件）// fs.renameSync(oldPath, newPath)
//1.改名  2.剪切文件  // 和linux下的mv很像
/** 可进行 1.改名  2.剪切文件 **/
//fs.rename('html/index.html','html/news.html',function(err){
//  if(err) return console.log(err)
//   console.log('修改名字/剪切文件成功');
//})


//8. fs.rmdir  删除目录 // fs.rmdirSync(path)
//fs.rmdir('t',function(err){
//  if(err) return console.log(err)
// 如果在文件上（而不是目录上）使用fs.rmdir()，
// 则 Windows 平台会导致 ENOENT 错误，POSIX 平台会导致 ENOTDIR 错误。
// ENOENT: no such file or directory, rmdir      rmdir 这个方法只能删除目录
//    console.log('删除目录成功');
//})


//9. fs.unlink删除文件 // fs.unlinkSync(path)
// fs.unlink('index.txt',function(err){
//  if(err) return console.log(err)
//     console.log('删除文件成功');
// })

