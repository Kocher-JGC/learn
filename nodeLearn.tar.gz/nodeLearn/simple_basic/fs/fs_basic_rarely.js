/** 不常用 **/
fs.access(path[, mode], callback)
// 检测 path 指定的文件或目录的用户权限
// 检查文件是否存在于当前目录。
/**
 * fs.constants.F_OK 存在性
 * fs.constants.R_OK 可读性
 * fs.constants.W_OK 可写性
 *  **/
// 检查文件是否存在于当前目录，且是否可写。
// const file = 'package.json';
// fs.access(file, fs.constants.F_OK | fs.constants.W_OK, (err) => {
//   if (err) {
//     console.error(`${file} ${err.code === 'ENOENT' ? '不存在' : '只可读'}`);
//   } else {
//     console.log(`${file} 存在，且可写`);
//   }
// });

fs.chmod(path, mode, callback) // 异步地改变文件的权限。 完成回调只有一个可能的异常参数。
/** 
 常量	                 八进制值     	描述
fs.constants.S_IRUSR	0o400	         所有者可读
fs.constants.S_IWUSR	0o200	         所有者可写
fs.constants.S_IXUSR	0o100	         所有者可执行或搜索
fs.constants.S_IRGRP	0o40           群组可读
fs.constants.S_IWGRP	0o20           群组可写
fs.constants.S_IXGRP	0o10           群组可执行或搜索
fs.constants.S_IROTH	0o4	           其他人可读
fs.constants.S_IWOTH	0o2	           其他人可写
fs.constants.S_IXOTH	0o1     	     其他人可执行或搜索
数字	描述
0	没有权限  1	只可执行
2	只写  3	可写、可执行
4	只读  5	可读、可执行
6	可读、可写  7	可读、可写、可执行
**/

fs.chown(path, uid, gid, callback) 异步地改变文件的所有者和群组。 完成回调只有一个可能的异常参数。

fs.close(fd, callback) 异步的 close(2)。 完成回调只有一个可能的异常参数。


fs.copyFile(src, dest[, flags], callback)
//异步地将 src 拷贝到 dest。 默认情况下，如果dest已存在则覆盖.回调函数只有一个可能的异常参数。
// Node.js 不能保证拷贝操作的原子性。 如果目标文件打开后出现错误，Node.js 会尝试删除它。
/** 
flags 是一个可选的整数，用于指定拷贝操作的行为。 可以使用两个或更多个值进行位或操作来创建掩码（比如 fs.constants.COPYFILE_EXCL | fs.constants.COPYFILE_FICLONE）。
fs.constants.COPYFILE_EXCL - 如果 dest 已存在，则拷贝操作会失败。
fs.constants.COPYFILE_FICLONE - 拷贝操作会试图创建一个写时拷贝（copy-on-write）链接。 如果平台不支持写时拷贝，则使用备选的拷贝机制。
fs.constants.COPYFILE_FICLONE_FORCE - 拷贝操作会试图创建一个写时拷贝链接。 如果平台不支持写时拷贝，则拷贝操作会失败。
**/

fs.existsSync(path)
fs.fchmod(fd, mode, callback) // fs.fchmodSync(fd, mode)
fs.fchown(fd, uid, gid, callback) // fs.fchownSync(fd, uid, gid)
fs.fdatasync(fd, callback) // fs.fdatasyncSync(fd)
fs.fstat(fd[, options], callback) //fs.fstatSync(fd[, options])
// options <Object>
// bigint <boolean> fs.Stats 对象返回的数值是否为长整数型。默认为 false。
fs.fsync(fd, callback) // fs.fsyncSync(fd)
fs.ftruncate(fd[, len], callback) // fs.ftruncateSync(fd[, len])
fs.futimes(fd, atime, mtime, callback) // fs.futimesSync(fd, atime, mtime)
fs.lchmod(path, mode, callback) // fs.lchmodSync(path, mode) 废弃于: v0.4.7
fs.lchown(path, uid, gid, callback) // fs.lchownSync(path, uid, gid)
fs.link(existingPath, newPath, callback) // fs.linkSync(existingPath, newPath)
fs.lstat(path[, options], callback) // fs.lstatSync(path[, options])


fs.readlink(path[, options], callback) // fs.readlinkSync(path[, options])
// 可选的 options 参数用于传入回调的链接路径，它可以是一个字符串并指定一个字符编码，或是一个对象且由一个 encoding 属性指定使用的字符编码。 
// 如果 encoding 设为 'buffer'，则返回的链接路径会被作为 Buffer 对象传入。
fs.realpath(path[, options], callback) // 异步地计算文件路径，解析 .、.. 与符号链接。
// fs.realpathSync(path[, options])
// 该函数与 realpath(3) 的区别在于
// 在大小写不敏感的文件系统，不会执行大小写转换。
// 符号链接的最大数量与平台无关，通常大于原生 realpath(3) 的。
// callback 有两个参数 (err, resolvedPath)。 可以使用 process.cwd 解析相对路径。
fs.realpath.native(path[, options], callback) // 新增于: v9.2.0
// fs.realpathSync.native(path[, options])
// 只支持可转换成 UTF8 字符串的路径。
// options 参数用于传入回调的路径，它可以是一个字符串并指定一个字符编码，或是一个对象且由一个 encoding 属性指定使用的字符编码。
// 如果 encoding 设为 'buffer'，则返回的路径会被作为 Buffer 对象传入。

fs.symlink(target, path[, type], callback) // fs.symlinkSync(target, path[, type])
/**
异步的 symlink(2)。 完成回调只有一个可能的异常参数。 
type 参数可以设为 'dir'、'file' 或 'junction'，且仅在 Windows 上有效（在其他平台上忽略）。 
Windows 上使用 'junction' 要求目标路径是绝对路径。 
当使用 'junction' 时，target 参数会被自动标准化为绝对路径。
例子，创建了一个名为 "new-port" 且指向 "foo" 的符号链接：
fs.symlink('./foo', './new-port', callback);
**/

fs.truncate(path[, len], callback) // fs.truncateSync(path[, len])
// 异步的 truncate(2)。 完成回调只有一个可能的异常参数。
// 第一个参数也可以是一个文件描述符，在这种情况下，fs.ftruncate() 会被调用。 
// 但这种用法已被废弃，不建议使用。


/** fs.watch() 比 fs.watchFile() 和 fs.unwatchFile() 更高效。 
 * 建议使用 fs.watch() 而不是 fs.watchFile() 和 fs.unwatchFile()。 **/
/**
// 监视 filename 的变化。 回调 listener 会在每次文件被访问时调用。
filename <string> | <Buffer> | <URL>
options <string> | <Object>
  persistent <boolean> 指明如果文件正在被监视，进程是否继续运行。默认为 true。
  recursive <boolean> 指明是监视全部子目录还是只有当前目录。 适用于监视目录时，且只在支持的平台有效（详见注意事项）。 默认为 false。
  encoding <string> 指定用于传给监听器的文件名的字符编码。默认为 'utf8'。
listener <Function> | <undefined> 默认为 undefined。
  eventType <string>
  filename <string> | <Buffer>
返回: <fs.FSWatcher> 
**/
fs.watch(filename[, options][, listener]) // filename 可以是一个文件或一个目录。
/**
在大多数平台，当目录中一个文件出现或消失时，就会触发 'rename' 事件。
监听器回调是绑定在由 fs.FSWatcher 触发的 'change' 事件上，但它跟 eventType 的 'change' 不是同一个东西。 
**/
fs.watchFile(filename[, options], listener) 
/**当 fs.watchFile() 所监听的文件消失并重新出现时，回调事件第二次返回的 previousStat（文件重新出现）会与第一次返回的 previousStat（文件消失）相同。
这种情况会发生在:
  文件被删除，然后又恢复。
  文件被重命名两次，且第二次重命名与其原名称相同。 
 *  **/
fs.unwatchFile(filename[, listener])
// 停止监视 filename 文件的变化。 如果指定了 listener，则只移除特定的监听器，否则移除全部监听器，且停止监视 filename。
// 调用 fs.unwatchFile() 且带上一个未被监视的文件名，将会是一个空操作，而不是一个错误。

fs.utimes(path, atime, mtime, callback) // 改变 path 所指向的对象的文件系统时间戳。
/** 参数 atime 和 mtime 遵循以下规则：
值可以是 Unix 时间戳数值、Date 对象、或数值字符串如 '123456789.0'。
如果值不能被转换为数值，或值是 NaN 、 Infinity 或 -Infinity，则会抛出错误。 **/