const fs = require('fs');

/** fs.ReadStream 类
'close' 事件 'open' 事件 'ready' 事件
readStream.bytesRead readStream.path 
**/

//fs.createReadStream(path[, options])
/** 
path <string> | <Buffer> | <URL>
options <string> | <Object>
  flags <string> 详见支持的 flag。默认为 'r'。
  encoding <string> 默认为 null。
  fd <integer> 默认为 null。文件描述符。
  mode <integer> 默认为 0o666。
  autoClose <boolean> 默认为 true。
  start <integer>
  end <integer> 默认为 Infinity。
  highWaterMark <integer> 默认为 64 * 1024。
返回: <fs.ReadStream>类
可读流的 highWaterMark 一般默认为 16 kb，但本方法返回的可读流默认为 64 kb。
start 与 end 用于从文件读取指定范围的字节。 
start 与 end 都是包括在内的。 如果指定了 fd 且不指定 start，则从当前位置开始读取。

如果指定了 fd，则忽略 path。 这意味着不会触发 'open' 事件。 、
fd 必须是阻塞的，非阻塞的 fd 应该传给 net.Socket。

如果 fd 是一个只支持阻塞读取（比如键盘或声卡）的字符设备，则读取操作在读取到数据之前不会结束。 
这可以避免进程退出或者流被关闭。
 *  **/
const readStream = fs.createReadStream('/dev/input/event0'); // 从字符设备创建可读流。
setTimeout(() => {
  stream.close(); // 这不会关闭流。
  // 必须手动地指示流已到尽头，流才会关闭。
  // 这不会取消读取操作的等待，进程在读取完成前不会退出。
  stream.push(null);
  stream.read(0);
}, 100);
var str='';/*保存数据*/
var count=0;  /*次数*/
readStream.on('data',function(chunk){
  str+=chunk;
  count++;
})
//读取完成
readStream.on('end',function(chunk){
  console.log(count);
  console.log(str);
})
//读取失败
readStream.on('error',function(err){
  console.log(err);
})

// 如果 autoClose 设为 false，则文件描述符不会自动关闭，即使发生错误。 
// 应用程序需要负责关闭它，并且确保没有文件描述符泄漏。 
// 如果 autoClose 设为 true（默认），则文件描述符在 error 或 end 事件时会自动关闭。
// mode 用于设置文件模式（权限），但仅限创建文件时有效。
// 例子，从一个大小为 100 字节的文件中读取最后 10 个字节：
//   fs.createReadStream('sample.txt', { start: 90, end: 99 });

// fs.createWriteStream(path[, options])

/** 
path <string> | <Buffer> | <URL>
options <string> | <Object>
  flags <string> 详见支持的 flag。默认为 'w'。
  encoding <string> 默认为 'utf8'。
  fd <integer> 默认为 null。文件描述符。
  mode <integer> 默认为 0o666。
  autoClose <boolean> 默认为 true。
  start <integer>
返回: <fs.WriteStream> 详见可写流。
start 用于写入数据到文件的指定位置。 如果要修改文件而不是覆盖文件，则 flags 应为 r+ 而不是默认的 w。

如果 autoClose 设为 true（默认），则文件描述符在 error 或 finish 事件时会自动关闭。 如果 autoClose 设为 false，则文件描述符不会自动关闭，即使发生错误。 应用程序需要负责关闭它，并且确保没有文件描述符泄漏。

如果指定了 fd，则忽略 path。 这意味着不会触发 'open' 事件。 fd 必须是阻塞的，非阻塞的 fd 应该传给 net.Socket。

如果 options 是一个字符串，则指定字符编码。
**/

var data = '我是从数据库获取的数据，我要保存起来11\n';

// 创建一个可以写入的流，写入到文件 output.txt 中
var writerStream = fs.createWriteStream('output.txt');
for(var i=0;i<100;i++){
  writerStream.write(data,'utf8');
}
writerStream.end(); //标记写入完成

writerStream.on('finish',function(){
  console.log('写入完成');
})
writerStream.on('error',function(){
  console.log('写入失败');
})


// 管道读写操作
// 读取 input.txt 文件内容，并将内容写入到 output.txt 文件中
readerStream.pipe(writerStream);
