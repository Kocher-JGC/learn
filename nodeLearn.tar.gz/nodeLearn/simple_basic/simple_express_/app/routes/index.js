console.log('init');

const router = require('express').Router();

module.exports = function initRouter(app) {
  router.get('/', (req, res) => {
    res.redirect('/home');
  });
  router.get('/home', (req, res) => {
    res.send('home');
  })
  app.use('/',router)
}