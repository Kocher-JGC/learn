const
  express = require('express'),
  app = new express();

/** 中间件 **/
// const
//   cookieParser = require('cookie-parser'),
//   session = require('express-session'),
//   md5 = require('md5-node'),
//   bodyParser = require('body-parser'),
//   multiparty = require('multiparty'); //???
  //拿POST文件数据 --> 专门解析 类型为 multipart/form-data 的数据
  // const multer = require('multer'); //???


  /** 2个方式 --> static 使用express自带的 **/
//配置public目录为我们的静态资源目录
// const expressStatic = require('express-static'); //??
// app.use(express.static('public'));
// app.use('/upload',express.static('upload'));
app.use(express.static('assets'));


/** 初始化路由 **/
const initRouter = require('./app/routes')
console.log(initRouter.toString());

initRouter(app);


app.listen(3003,'127.0.0.1');