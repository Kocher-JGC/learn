// js import 导入 
// export const deee = {
//   test: 'This is my first NPM project 我的第一个项目'
// }
// node 导入model --> require
module.exports = 'This is my first NPM project 我的第一个项目'
