module.exports = 'This is my first NPM project 我的第一个项目'
